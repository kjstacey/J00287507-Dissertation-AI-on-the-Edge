# EMNIST Balanced compact CNN — Cloud Run

Separate service preserving the MNIST FPGA client wire contract:

- `POST /predict`, `Content-Type: application/octet-stream`
- Request body: exactly 784 **already-oriented**, row-major 8-bit pixel bytes (28×28). Do not send IDX header or apply a second transpose.
- Server input: bytes converted to float and divided by **255.0**, matching PyTorch training (MNIST `/128.0` is not applicable).
- Response: `{"prediction": 0}` through `{"prediction": 46}`.
- `GET /` health response.

Model: `CompactCNN-16-32-64-GAP-47`; checkpoint is the actual compact FPGA candidate (`best_cnn_checkpoint(2).pt` in source uploads), not the larger improved CNN checkpoint.

## Deploy from Windows PowerShell

```powershell
cd "C:\path\to\EMNIST_Cloud_Run_Service"
gcloud config set project YOUR_PROJECT_ID
gcloud run deploy emnist-cloud-inference --source . --region us-east1 --allow-unauthenticated
```

Use an independent service name so the MNIST endpoint remains unchanged. Deployment requires authorized `gcloud` credentials and Cloud Run/Cloud Build/Artifact Registry APIs, permissions, and billing.

## Verify locally (optional)

```powershell
python3 -m pip install -r requirements.txt
python3 -m pip install torch==2.5.1 --index-url https://download.pytorch.org/whl/cpu
python3 main.py
```

`curl` may be used to POST 784 raw bytes to `/predict`. A request of any other size must return HTTP 400. Verify known labeled EMNIST inputs before testing the SDK.

## SDK changes needed later

In MNIST `tcp_client.c`, replace `CLOUD_HOST` with the new Cloud Run hostname. **Also update the response parser:** it currently consumes just one digit (`*prediction_text - '0'`) and is invalid for EMNIST predictions 10–46. Its transport and JSON field can otherwise remain consistent. Keep the TLS development configuration's lack of certificate verification and noncryptographic entropy source identified as security limitations; do not deploy them in production.

Do not measure Cloud Run accuracy by forwarding the FPGA's binary thresholded camera image if the intended controlled experiment uses original grayscale EMNIST test data. In cloud benchmarks, send the same correctly oriented grayscale bytes used for local EMNIST test images.

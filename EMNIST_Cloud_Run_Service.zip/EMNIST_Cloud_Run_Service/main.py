"""EMNIST Balanced compact-CNN inference service for ZedBoard raw-byte requests."""
import os
import numpy as np
import torch
from torch import nn
from flask import Flask, jsonify, request


class CompactCNN(nn.Module):
    """Matches train_emnist_compact_fpga_candidate.py exactly."""
    def __init__(self):
        super().__init__()
        self.features = nn.Sequential(
            nn.Conv2d(1, 16, 3, padding=1), nn.ReLU(),
            nn.MaxPool2d(2),
            nn.Conv2d(16, 32, 3, padding=1), nn.ReLU(),
            nn.MaxPool2d(2),
            nn.Conv2d(32, 64, 3, padding=1), nn.ReLU(),
        )
        self.pool = nn.AdaptiveAvgPool2d(1)
        self.classifier = nn.Linear(64, 47)

    def forward(self, x):
        return self.classifier(torch.flatten(self.pool(self.features(x)), 1))


torch.set_num_threads(int(os.environ.get('TORCH_NUM_THREADS', '1')))
app = Flask(__name__)
model = CompactCNN()
checkpoint = torch.load(os.path.join(os.path.dirname(__file__), 'best_cnn_checkpoint.pt'),
                        map_location='cpu', weights_only=True)
if checkpoint.get('architecture') != 'CompactCNN-16-32-64-GAP-47':
    raise ValueError('Unexpected checkpoint architecture')
model.load_state_dict(checkpoint['model_state_dict'], strict=True)
model.eval()


@app.get('/')
def health():
    return 'EMNIST Balanced compact-CNN cloud inference service is running'


@app.post('/predict')
def predict():
    data = request.get_data()
    if len(data) != 784:
        return jsonify(error='expected exactly 784 bytes', received=len(data)), 400

    # The ZedBoard transmits already-oriented 28x28 pixels, row-major,
    # 8-bit grayscale. Do NOT transpose again on the server.
    pixels = np.frombuffer(data, dtype=np.uint8).astype(np.float32) / 255.0
    tensor = torch.from_numpy(pixels.copy()).reshape(1, 1, 28, 28)
    with torch.inference_mode():
        prediction = int(model(tensor).argmax(dim=1).item())
    return jsonify(prediction=prediction)


if __name__ == '__main__':
    app.run(host='0.0.0.0', port=int(os.environ.get('PORT', '8080')))

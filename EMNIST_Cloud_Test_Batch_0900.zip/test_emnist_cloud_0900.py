#!/usr/bin/env python3
"""Verify the EMNIST Cloud Run endpoint using the exact 900-999 FPGA ROM batch.

Usage:
  python3 test_emnist_cloud_0900.py                 # First 5 images
  python3 test_emnist_cloud_0900.py --count 100     # Entire batch
"""
import argparse
import csv
import json
from pathlib import Path
from urllib.error import HTTPError, URLError
from urllib.request import Request, urlopen

DEFAULT_URL = "https://emnist-cloud-inference-221036165238.us-east1.run.app/predict"
HERE = Path(__file__).resolve().parent


def load_coe(path):
    raw = path.read_text(encoding="utf-8-sig")
    header, separator, values = raw.partition("memory_initialization_vector=")
    if not separator:
        raise ValueError("COE missing memory_initialization_vector=")
    if "memory_initialization_radix=16" not in header.replace(" ", "").lower():
        raise ValueError("Expected a radix-16 COE file")
    tokens = [part.strip() for part in values.strip().rstrip(";").split(",")]
    pixels = bytes(int(token, 16) for token in tokens if token)
    if len(pixels) != 100 * 784:
        raise ValueError(f"Expected 78,400 pixels, found {len(pixels)}")
    return pixels


def load_labels(path):
    with path.open(newline="", encoding="utf-8-sig") as f:
        rows = list(csv.DictReader(f))
    if len(rows) != 100:
        raise ValueError(f"Expected 100 label rows, found {len(rows)}")
    labels = []
    for pos, row in enumerate(rows):
        batch_pos = int(row["batch_position"])
        index = int(row["original_test_index"])
        label = int(row["class_id"])
        if batch_pos != pos or index != 900 + pos or not 0 <= label <= 46:
            raise ValueError(f"Unexpected label/index at row {pos}: {row}")
        labels.append((index, label))
    return labels


def predict(url, image):
    req = Request(url, data=image, method="POST",
                  headers={"Content-Type": "application/octet-stream"})
    with urlopen(req, timeout=90) as response:
        payload = json.load(response)
    prediction = payload.get("prediction")
    if type(prediction) is not int or not 0 <= prediction <= 46:
        raise ValueError(f"Invalid prediction response: {payload}")
    return prediction


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--count", type=int, default=5, help="Images to test (1-100; default 5)")
    parser.add_argument("--url", default=DEFAULT_URL, help="Cloud Run /predict URL")
    args = parser.parse_args()
    if not 1 <= args.count <= 100:
        parser.error("--count must be 1..100")
    pixels = load_coe(HERE / "emnist_test_pixels_0900.coe")
    labels = load_labels(HERE / "emnist_test_labels_0900.csv")
    correct = 0
    print("Index   Expected   Predicted   Match")
    print("-----   --------   ---------   -----")
    for pos in range(args.count):
        original_index, expected = labels[pos]
        image = pixels[pos * 784:(pos + 1) * 784]
        try:
            actual = predict(args.url, image)
        except (HTTPError, URLError, ValueError) as error:
            raise SystemExit(f"Request failed at index {original_index}: {error}") from error
        match = actual == expected
        correct += match
        print(f"{original_index:>5}   {expected:>8}   {actual:>9}   {'YES' if match else 'NO'}")
    print(f"\nCorrect: {correct}/{args.count} ({correct / args.count:.1%})")
    print("Diagnostic Cloud Run test; not a formal FPGA cloud-accuracy measurement.")


if __name__ == "__main__":
    main()
